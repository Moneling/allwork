;(function(){
	function warn_(check_length){

		if(check_length==0){
			 $(".warn_div").css({"top":"10px","-webkit-transition":"top 1s ease-in"}).find("span").text("请选择要操作的选项");
                setTimeout(function(){
                	$(".warn_div").css({"top":"-100px","-webkit-transition":"top 1s ease-in"})
                },3000);
		}else if(check_length>1){
			 $(".warn_div").css({"top":"10px","-webkit-transition":"top 1s ease-in"}).find("span").text("只能选择一项操作");
            setTimeout(function(){
            	$(".warn_div").css({"top":"-100px","-webkit-transition":"top 1s ease-in"})
            },3000);
		}
		
	}
	function info_alert(title_txt,title){
		var html="<div class='module_mask'></div>";
		    $("body").append(html);  
		    $("#write_edit").show();
		    $("#widget_header>h5").find("span").text(title_txt);
		    $("#widget_header .smaller").html(title);
	}
	function info_examine(){
		var name = $("#grid-table").find("input:checked").parents("tr").find("td[aria-describedby='grid-table_name']").text();
		var id = $("#grid-table").find("input:checked").parents("tr").find("td[aria-describedby='grid-table_id']").text();
		$("#info_name").find("input").val(name);
		$("#info_resource").find("input").val("publicinfo_create");
		$("#info_id").find("input").val(id);
	}
	$("#grid-pager_left").on("click","td",function(){
	      var text=$(this).attr("data-original-title");  
		  var title=$(this).attr("data-title"); 
	     if(text=="修改权限"){
      		var checked_l=$("#grid-table").find("input:checked").length;

      		if(checked_l==1){
      			info_alert(text,title);
      			info_examine();
               
      		}else if(checked_l>1){
                warn_(checked_l);
      		}
      		else if(checked_l==0){
                warn_(checked_l);
      		}
         
      	}		     
    })
    function write_Look(){
		$("#write_edit").hide();
		$(".module_mask").remove();
	    $("#widet_body select").each(function(i){
			$(this).find("option").eq(0).attr("selected",true).siblings("option").attr("selected",false);
		});
	}
	$(".widget-toolbar").on("click","span",function(){
		write_Look();
	})
	$(".save_bottom").on("click",".cancel_btn",function(){
		write_Look();
	})
})(jQuery)