var  grid_data = [];
var setting = {
	view: {
		dblClickExpand: false
	},
	check: {
		enable: true
	},
	data: {
		simpleData: {
			enable: true
		}
	},
	callback: {
		onClick: onClick,
		beforeClick: function(treeId, treeNode) {
			liList(treeId, treeNode);
		}
	}
};

var zNodes =[
	{ id:1, pId:0, name:"root",open:true},
	{ id:11, pId:1, name:"系统管理"},
	{ id:111, pId:11, name:"管理员管理"},
	{ id:1111, pId:111, name:"添加"},
	{ id:1112, pId:111, name:"删除"},
	{ id:1113, pId:111, name:"修改"},
	{ id:1114, pId:111, name:"查看"},
	{ id:1115, pId:111, name:"高级搜索"},
	{ id:1116, pId:111, name:"显示全部"},
	{ id:1117, pId:111, name:"重置密码"},
	{ id:112, pId:11, name:"权限组管理"},
	{ id:1121, pId:112, name:"添加"},
	{ id:1122, pId:112, name:"删除"},
	{ id:1123, pId:112, name:"修改"},
	{ id:1124, pId:112, name:"查看"},
	{ id:113, pId:11, name:"模块管理"},
	{ id:1131, pId:113, name:"修改"},
	{ id:114, pId:11, name:"登录注销日志"},
	{ id:1141, pId:114, name:"高级搜索"},
	{ id:1142, pId:114, name:"显示全部"},
	{ id:1143, pId:114, name:"图标"},
	{ id:115, pId:11, name:"系统日志"},
	{ id:1151, pId:115, name:"查看"},
	{ id:1152, pId:115, name:"高级搜索"},
	{ id:1153, pId:115, name:"显示全部"},
	{ id:12, pId:1, name:"公众号管理"},
	{ id:121, pId:12, name:"公众号信息"},
	{ id:1211, pId:121, name:"添加"},
	{ id:1212, pId:121, name:"查看"},
	{ id:1213, pId:121, name:"修改"},
	{ id:122, pId:12, name:"菜单管理"},
	{ id:1221, pId:122, name:"添加"},
	{ id:1222, pId:122, name:"查看"},
	{ id:1223, pId:122, name:"修改"},
	{ id:1224, pId:122, name:"删除"},
	{ id:1225, pId:122, name:"菜单同步"},
	{ id:13, pId:1, name:"素材管理"},
	{ id:131, pId:13, name:"文本消息创建"},
	{ id:1311, pId:131, name:"添加"},
	{ id:1312, pId:131, name:"删除"},
	{ id:1313, pId:131, name:"修改"},
	{ id:1314, pId:131, name:"查看"},
	{ id:132, pId:13, name:"图文消息创建"},
	{ id:1321, pId:132, name:"添加"},
	{ id:1322, pId:132, name:"删除"},
	{ id:1323, pId:132, name:"修改"},
	{ id:1324, pId:132, name:"查看"},
	{ id:133, pId:13, name:"素材消息创建"},
	{ id:1331, pId:133, name:"添加"},
	{ id:1332, pId:133, name:"删除"},
	{ id:1333, pId:133, name:"修改"},
	{ id:1334, pId:133, name:"查看"},
	{ id:14, pId:1, name:"微信用户管理"},
	{ id:141, pId:14, name:"关注用户"},
	{ id:1411, pId:141, name:"查看"},
	{ id:1412, pId:141, name:"高级搜索"},
	{ id:1413, pId:141, name:"查看全部"},
	{ id:1414, pId:141, name:"分组"},
	{ id:142, pId:14, name:"取消关注用户"},
	{ id:15, pId:1, name:"消息管理"},
	{ id:151, pId:15, name:"接收消息"},
	{ id:1511, pId:151, name:"查看"},
	{ id:1512, pId:151, name:"高级搜索"},
	{ id:1513, pId:151, name:"查看全部"},
	{ id:152, pId:15, name:"群发消息"},
	{ id:1521, pId:152, name:"群发选择发送"},
	{ id:1522, pId:152, name:"删除"},
	{ id:153, pId:15, name:"消息自动回复"},
	{ id:1531, pId:153, name:"添加"},
	{ id:1532, pId:153, name:"删除"},
	{ id:1533, pId:153, name:"修改"},
	{ id:1534, pId:153, name:"查看"},
	{ id:154, pId:15, name:"分组管理"},
	{ id:1541, pId:154, name:"添加"},
	{ id:1542, pId:154, name:"删除"},
	{ id:1543, pId:154, name:"修改"},
	{ id:1544, pId:154, name:"查看"},
	{ id:16, pId:1, name:"活动发布"},
	{ id:161, pId:16, name:"活动管理"},
	{ id:1611, pId:161, name:"添加"},
	{ id:1612, pId:161, name:"删除"},
	{ id:1613, pId:161, name:"修改"},
	{ id:1614, pId:161, name:"查看"},
	{ id:162, pId:16, name:"抽奖详情"},
	{ id:1621, pId:162, name:"高级搜索"},
	{ id:1622, pId:162, name:"查看"},
	{ id:1623, pId:162, name:"查看全部"},
	{ id:17, pId:1, name:"统计分析"},
	{ id:171, pId:17, name:"关注用户比例图表"},
	{ id:172, pId:17, name:"取消关注用户增长趋势图表"},
	{ id:173, pId:17, name:"关注用户增长趋势图表"},
	{ id:174, pId:17, name:"取消关注用户比例表"}
];

var code;

function showCode(str) {
	if (!code) code = $("#code");
	code.empty();
	code.append("<li>"+str+"</li>");
}
function onClick(treeNode) {
	var zTree = $.fn.zTree.getZTreeObj("treeDemo");
	zTree.expandNode(treeNode);
	var grid_data = [];
	var mygrid = jQuery("#grid-table")[0];
	$("#grid-table").jqGrid('clearGridData');
	mygrid.addJSONData(grid_data);
}
$(document).ready(function(){
	$.fn.zTree.init($("#treeDemo"), setting, zNodes);
	$.each(zNodes,function(key,val){
		if(val.open){
			$.each(zNodes,function(k,v){
				if(v.pId == val.id){
					grid_data.push(v);
				}
			})
		}
	})
	gridData(grid_data);
});
function liList(treeId, treeNode){
	grid_data =[];
	$.each(treeNode.children,function(key,val){
		if(treeNode.children.length>=0){
			grid_data.push(val);
		}else{
			console.log(grid_data);
		}
	})
	gridData(grid_data);
}
// var grid_data = 
// 	[ 
// 		{id:"1",APPname:"Desktop Computer",password:"qwdwee",name:"qwdf",note:"note",state:"已审核"},
// 		{id:"2",APPname:"Laptop",password:"qwdwee",name:"qwdf",note:"Long text ",state:"已审核"},
// 		{id:"3",APPname:"LCD Monitor",password:"qwdwee",name:"qwdf",note:"note3",state:"已审核"},
// 		{id:"4",APPname:"Speakers",password:"qwdwee",name:"qwdf",note:"note",state:"已审核"},
// 		{id:"5",APPname:"Laser Printer",password:"qwdwee",name:"qwdf",note:"note2",state:"已审核"},
// 		{id:"6",APPname:"Play Station",password:"qwdwee",name:"qwdf",note:"note3",state:"已审核"},
// 		{id:"7",APPname:"Mobile Telephone",password:"qwdwee",name:"qwdf",note:"note",state:"已审核"},
// 		{id:"8",APPname:"Server",password:"qwdwee",name:"qwdf",note:"note2",state:"已审核"},
// 		{id:"9",APPname:"Matrix Printer",password:"qwdwee",name:"qwdf",note:"note3",state:"已审核"},
// 		{id:"10",APPname:"Desktop Computer",password:"qwdwee",name:"qwdf",note:"note",state:"已审核"},
// 		{id:"11",APPname:"Laptop",password:"qwdwee",name:"qwdf",note:"Long text ",state:"已审核"}
// 	];	

function gridData(grid_data) {
	var grid_selector = "#grid-table";
	var pager_selector = "#grid-pager";

	jQuery(grid_selector).jqGrid({
		//direction: "rtl",
		
		data: grid_data,
		datatype: "local",
		height: 250,
		colNames:['编号','中文名称','英文名称','顺序号','是否显示', '是否启用'],
		colModel:[
			{name:'id',index:'id', width:40, sorttype:"int", editable: true},
			{name:'name',index:'name',width:100, editable:true, sorttype:"int"},
			{name:'password',index:'password',width:100, editable:true, sorttype:"date",unformat: pickDate},
			/*{name:'password',index:'stock', width:70, editable: true,edittype:"checkbox",editoptions: {value:"Yes:No"},unformat: aceSwitch},*/
			{name:'APPname',index:'name', width:150,editable: true,editoptions:{size:"20",maxlength:"30"}},
			{name:'state',index:'state', width:90, editable: true,edittype:"select",editoptions:{value:"FE:已审核;IN:未审核"}},
			{name:'note',index:'note',width:90, editable:true, sorttype:"int"}

			/*{name:'email',index:'stock', width:150, editable: true,edittype:"checkbox",editoptions: {value:"Yes:No"},unformat: aceSwitch},*/
			
		], 

		viewrecords : true,
		rowNum:10,
		rowList:[10,20,30],
		pager : pager_selector,
		altRows: true,
		//toppager: true,
		
		multiselect: true,
		//multikey: "ctrlKey",
        multiboxonly: true,

		loadComplete : function() {
			var table = this;
			setTimeout(function(){
				styleCheckbox(table);
				
				updateActionIcons(table);
				updatePagerIcons(table);
				enableTooltips(table);
			}, 0);
		},

		// editurl: $path_base,//nothing is saved 
		caption: "管理员管理",


		autowidth: true

	});

	//enable search/filter toolbar
	//jQuery(grid_selector).jqGrid('filterToolbar',{defaultSearch:true,stringResult:true})

	//switch element when editing inline
	function aceSwitch( cellvalue, options, cell ) {
		setTimeout(function(){
			$(cell) .find('input[type=checkbox]')
					.wrap('<label class="inline" />')
				.addClass('ace ace-switch ace-switch-5')
				.after('<span class="lbl"></span>');
		}, 0);
	}
	//enable datepicker
	function pickDate( cellvalue, options, cell ) {
		setTimeout(function(){
			$(cell) .find('input[type=text]')
					.datepicker({format:'yyyy-mm-dd' , autoclose:true}); 
		}, 0);
	}


	//navButtons
	jQuery(grid_selector).jqGrid('navGrid',pager_selector,
		{ 	//navbar options
			edit: false,
			editicon : 'icon-pencil blue',
			add: false,
			addicon : 'icon-plus-sign purple',
			del: false,
			delicon : 'icon-trash red',
			search: false,
			searchicon : 'icon-search orange',
			search: false,
			searchicon : 'icon-search orange',
			reset:false,
			reseticon:'icon-retweet green',
			refresh: false,
			refreshicon : 'icon-refresh green',
			view: false,
			viewicon : 'icon-zoom-in grey',
		},
		{
			//edit record form
			//closeAfterEdit: true,
			recreateForm: true,
			beforeShowForm : function(e) {
				var form = $(e[0]);
				form.closest('.ui-jqdialog').find('.ui-jqdialog-titlebar').wrapInner('<div class="widget-header" />')
				style_edit_form(form);
			}
		},
		{
			//new record form
			closeAfterAdd: true,
			recreateForm: true,
			viewPagerButtons: false,
			beforeShowForm : function(e) {
				var form = $(e[0]);
				form.closest('.ui-jqdialog').find('.ui-jqdialog-titlebar').wrapInner('<div class="widget-header" />')
				style_edit_form(form);
			}
		},
		{
			//delete record form
			recreateForm: true,
			beforeShowForm : function(e) {
				var form = $(e[0]);
				if(form.data('styled')) return false;
				
				form.closest('.ui-jqdialog').find('.ui-jqdialog-titlebar').wrapInner('<div class="widget-header" />')
				style_delete_form(form);
				
				form.data('styled', true);
			},
			onClick : function(e) {
				alert(1);
			}
		},
		{
			//search form
			recreateForm: true,
			afterShowSearch: function(e){
				var form = $(e[0]);
				form.closest('.ui-jqdialog').find('.ui-jqdialog-title').wrap('<div class="widget-header" />')
				style_search_form(form);
			},
			afterRedraw: function(){
				style_search_filters($(this));
			}
			,
			multipleSearch: true,
			/**
			multipleGroup:true,
			showQuery: true
			*/
		},
		{
			//view record form
			recreateForm: true,
			beforeShowForm: function(e){
				var form = $(e[0]);
				form.closest('.ui-jqdialog').find('.ui-jqdialog-title').wrap('<div class="widget-header" />')
			}
		}
	)


	
	function style_edit_form(form) {
		//enable datepicker on "sdate" field and switches for "stock" field
		form.find('input[name=sdate]').datepicker({format:'yyyy-mm-dd' , autoclose:true})
			.end().find('input[name=stock]')
				  .addClass('ace ace-switch ace-switch-5').wrap('<label class="inline" />').after('<span class="lbl"></span>');

		//update buttons classes
		var buttons = form.next().find('.EditButton .fm-button');
		buttons.addClass('btn btn-sm').find('[class*="-icon"]').remove();//ui-icon, s-icon
		buttons.eq(0).addClass('btn-primary').prepend('<i class="icon-ok"></i>');
		
		buttons.eq(1).prepend('<i class="icon-remove"></i>')
		
		buttons = form.next().find('.navButton a');
		buttons.find('.ui-icon').remove();
		buttons.eq(0).append('<i class="icon-chevron-left"></i>');
		buttons.eq(1).append('<i class="icon-chevron-right"></i>');		
	}

	function style_delete_form(form) {
		var buttons = form.next().find('.EditButton .fm-button');
		buttons.addClass('btn btn-sm').find('[class*="-icon"]').remove();//ui-icon, s-icon
		buttons.eq(0).addClass('btn-danger').prepend('<i class="icon-trash"></i>');
		buttons.eq(1).prepend('<i class="icon-remove"></i>')
	}
	
	function style_search_filters(form) {
		form.find('.delete-rule').val('X');
		form.find('.add-rule').addClass('btn btn-xs btn-primary');
		form.find('.add-group').addClass('btn btn-xs btn-success');
		form.find('.delete-group').addClass('btn btn-xs btn-danger');
	}
	function style_search_form(form) {
		var dialog = form.closest('.ui-jqdialog');
		var buttons = dialog.find('.EditTable')
		buttons.find('.EditButton a[id*="_reset"]').addClass('btn btn-sm btn-info').find('.ui-icon').attr('class', 'icon-retweet');
		buttons.find('.EditButton a[id*="_query"]').addClass('btn btn-sm btn-inverse').find('.ui-icon').attr('class', 'icon-comment-alt');
		buttons.find('.EditButton a[id*="_search"]').addClass('btn btn-sm btn-purple').find('.ui-icon').attr('class', 'icon-search');
	}
	
	function beforeDeleteCallback(e) {
		var form = $(e[0]);
		if(form.data('styled')) return false;
		
		form.closest('.ui-jqdialog').find('.ui-jqdialog-titlebar').wrapInner('<div class="widget-header" />')
		style_delete_form(form);
		
		form.data('styled', true);
	}
	
	function beforeEditCallback(e) {
		var form = $(e[0]);
		form.closest('.ui-jqdialog').find('.ui-jqdialog-titlebar').wrapInner('<div class="widget-header" />')
		style_edit_form(form);
	}



	//it causes some flicker when reloading or navigating grid
	//it may be possible to have some custom formatter to do this as the grid is being created to prevent this
	//or go back to default browser checkbox styles for the grid
	function styleCheckbox(table) {
	/**
		$(table).find('input:checkbox').addClass('ace')
		.wrap('<label />')
		.after('<span class="lbl align-top" />')


		$('.ui-jqgrid-labels th[id*="_cb"]:first-child')
		.find('input.cbox[type=checkbox]').addClass('ace')
		.wrap('<label />').after('<span class="lbl align-top" />');
	*/
	}
	

	//unlike navButtons icons, action icons in rows seem to be hard-coded
	//you can change them like this in here if you want
	function updateActionIcons(table) {
		/**
		var replacement = 
		{
			'ui-icon-pencil' : 'icon-pencil blue',
			'ui-icon-trash' : 'icon-trash red',
			'ui-icon-disk' : 'icon-ok green',
			'ui-icon-cancel' : 'icon-remove red'
		};
		$(table).find('.ui-pg-div span.ui-icon').each(function(){
			var icon = $(this);
			var $class = $.trim(icon.attr('class').replace('ui-icon', ''));
			if($class in replacement) icon.attr('class', 'ui-icon '+replacement[$class]);
		})
		*/
	}
	
	//replace icons with FontAwesome icons like above
	function updatePagerIcons(table) {
		var replacement = 
		{
			'ui-icon-seek-first' : 'icon-double-angle-left bigger-140',
			'ui-icon-seek-prev' : 'icon-angle-left bigger-140',
			'ui-icon-seek-next' : 'icon-angle-right bigger-140',
			'ui-icon-seek-end' : 'icon-double-angle-right bigger-140'
		};
		$('.ui-pg-table:not(.navtable) > tbody > tr > .ui-pg-button > .ui-icon').each(function(){
			var icon = $(this);
			var $class = $.trim(icon.attr('class').replace('ui-icon', ''));
			
			if($class in replacement) icon.attr('class', 'ui-icon '+replacement[$class]);
		})
	}

	function enableTooltips(table) {
		$('.navtable .ui-pg-button').tooltip({container:'body'});
		$(table).find('.ui-pg-div').tooltip({container:'body'});
	}

	//var selr = jQuery(grid_selector).jqGrid('getGridParam','selrow');


};