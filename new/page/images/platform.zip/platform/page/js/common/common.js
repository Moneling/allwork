//load datas at once
ajaxConect("get","../assets/datas/leftMenuData.json","",leftMenuData);

function leftMenuData(data){
	//console.log(data);
	
	//get ulContain elements
	var menuContain=$("#nav-list");//ul contain
	var mark=menuContain.attr("mark");//mark which menu is actived
	var active;//make a active mark
	
	var str="";//menu contain
	var urlArr=[];//parents url array
	var subUrlArr=[];//sub url array
	var springUrlArr=[];//spring url array
	//first menu
	$.each(data,function(i,item){
		var children=item["children"];//sub menu
		var iconCls=item["iconCls"];//iconCls
		var id=item["id"];//id
		var leaf=item["leaf"];//leaf
		var txt=item["text"];//text
		var _url=item["url"];//url
		urlArr.push(_url);//export parents url datas
		_url=_url?_url:"#";//handle url
		active=mark==i?"active":"";//handle active mark
		
		//console.log(children+"iconCls="+iconCls+"id="+id+"leaf="+leaf+"text="+txt+"url="+_url);
		str+="<li id='"+id+"' leaf='"+leaf+"' iconCls='"+iconCls+"' class='"+active+"'>";
		str+="<a href='"+_url+"' class='dropdown-toggle'>";
		str+="<i class='icon-desktop'></i>";
		str+="<span class='menu-text'>"+txt+"</span>";
		if (children && children.length>0 && leaf==="false") {
			str+="<b class='arrow icon-angle-down'></b>";
		} else{
			str+="";
		}
		str+="</a>";
		if(children && children.length>0  && leaf==="false"){
			//second menu
			str+="<ul class='submenu'>";
			$.each(children,function(i,subItem){
				var subChildren=subItem["children"];//sub menu
				var subIconCls=subItem["iconCls"];//subIconCls
				var subId=subItem["id"];//subId
				var subLeaf=subItem["leaf"];//subLeaf
				var subTxt=subItem["text"];//subTxt
				var subUrl=subItem["url"];//subUrl
				subUrlArr.push(subUrl);//exports sub url datas
				subUrl=subUrl?subUrl:"#";//handle subUrl
				str+="<li subId='"+subId+"' subLeaf='"+subLeaf+"' subIconCls='"+subIconCls+"'>";
				str+="<a href='"+subUrl+"' class='dropdown-toggle'>";
				str+="<i class='icon-double-angle-right'></i>";
				str+=subTxt;
				if(subChildren && subChildren.length>0 && subLeaf==="false"){
					str+="<b class='arrow icon-angle-down'></b>";
				}else{
					str+="";
				}
				str+="</a>";
				if(subChildren && subChildren.length>0  && subLeaf==="false"){
					//third menu
					str+="<ul class='submenu springMenu'>";
					$.each(subChildren, function(i,springItem) {
						var springChildren=springItem["children"];//spring menu
						var springIconCls=springItem["iconCls"];//springIconCls
						var springId=springItem["id"];//springId
						var springLeaf=springItem["leaf"];//springLeaf
						var springTxt=springItem["text"];//springTxt
						var springUrl=springItem["url"];//springUrl
						springUrlArr.push(springUrl);//exports spring url datas
						springUrl=springUrl?springUrl:"#";//handle springUrl
						str+="<li>";
						str+="<a href='"+springUrl+"' class='dropdown-toggle'>";
						str+="<i class='icon-double-angle-right'></i>";
						str+=springTxt;
						if(springChildren && springChildren.length>0 && springLeaf==="false"){
							str+="<b class='arrow icon-angle-down'></b>";
						}else{
							str+="";
						}
						str+="</a>";
						str+="</li>";//spring li
					});
					str+="</ul>";//spring ul
				}else{
					str+="";
				}
				str+="</li>";//sub li
			})			
			str+="</ul>";//sub ul
		}else{
			str+="";
		}
		str+="</li>";//first li		
	})
	menuContain.html(str);//when those labels loaded successlly,load js files
	console.log("urlArr="+urlArr);
	console.log("subUrlArr="+subUrlArr+"--------length="+subUrlArr.length);
	console.log("springUrlArr="+springUrlArr);
}
