;(function($){
   
	//提示框
	function warn_(check_length){

		if(check_length==0){
			 $(".warn_div").css({"top":"10px","-webkit-transition":"top 1s ease-in"}).find("span").text("请选择要操作的选项");
                setTimeout(function(){
                	$(".warn_div").css({"top":"-100px","-webkit-transition":"top 1s ease-in"})
                },3000);
		}else if(check_length>1){
			 $(".warn_div").css({"top":"10px","-webkit-transition":"top 1s ease-in"}).find("span").text("只能选择一项操作");
            setTimeout(function(){
            	$(".warn_div").css({"top":"-100px","-webkit-transition":"top 1s ease-in"})
            },3000);
		}
		
	}
/*弹出框*/
function write_Look(){
	$(".ui-sortable").hide();
	$(".admini_mask").remove();
	$(".admini_inline").css("display","none");
    $(".admini_block").css("display","none");
    $("#widet_body select").each(function(i){
		$(this).find("option").eq(0).attr("selected",true).siblings("option").attr("selected",false);
	});
}

function info_alert(title_txt,title){
	var html="<div class='admini_mask'></div>";
	    $("body").append(html);  
	    $(".write_div").show();
	    $("#widget_header>h5").find("span").text(title_txt);
	    $("#widget_header .smaller").html(title);
}
function info_reset(){
	$("#widet_body input").each(function(){
	    var value = $(this).val("");

	});
	$("#widet_body select").each(function(i){
		$(this).find("option").eq(0).attr("selected",true).siblings("option").attr("selected",false);
	});
}
function info_examine(){
//	function init(){
//		$.ajax({
//			url:"../management/user!query.action",
//			type:"get",
//			dataType:"json",
//			success : function(data){
//				examineArr(data);
//				
//			}
//		})
//	}
//	init();
//	function examineArr(data){
//		var examin_string = data.root; 
//		var str = $("#grid-table").find("input:checked").parents("tr").find("td[aria-describedby='grid-table_id']").text();
//		examin_arr = examin_string.filter(function(item){ 
//		    return item.id==str;
//		});
//		console.log(examin_string);
//		$("#info_name").find("input").val(examin_arr[0].username);
//		$("#info_name2").find("input").val(examin_arr[0].fullName);
//		if($("#info_role").find('option[value="'+examin_arr[0].roleName+'"]')){
//			console.log(1);
//		}else{
//			console.log(2);
//		}
//		$("#info_state select").each(function(i){
//			$(this).find("option").eq("'+examin_arr[0].enabled+'").attr("selected",true).siblings("option").attr("selected",false);
//		});
////		$("#info_state").find('option[value="'+examin_arr[0].enabled+'"]').attr("selected",true).siblings("option").attr("selected",false);
//		$("#info_email").find("input").val(examin_arr[0].email);
//		$("#info_role").find('option[value="'+examin_arr[0].roleName+'"]').attr("selected",true).siblings("option").attr("selected",false);
//		$("#info_region").find('option[value="'+examin_arr[0].area+'"]').attr("selected",true).siblings("option").attr("selected",false);
//		$("#info_public").find('option[value="'+examin_arr[0].publicName+'"]').attr("selected",true).siblings("option").attr("selected",false);
//		$("#info_remarks").find("input").val(examin_arr[0].description);
//	}
		var examin_string = [
				{"enabled":"启用","status":0,"roleName":"超级管理员","version":1,"id":1,"username":"admin","area":"省分","email":"fly@qq.com","publicName":"测试公众号","description":"111111111","publicId":3,"fullName":"fly","roleId":1},
				{"enabled":"启用","status":0,"roleName":"超级管理员","version":1,"id":2,"username":"linfen","area":"10","email":"3234343","publicName":"测试公众号","description":"这是一个备注1","publicId":3,"fullName":"临汾联通","roleId":1},
				{"enabled":"启用","status":0,"roleName":"超级管理员","version":1,"id":3,"username":"fly","area":"太原市","email":"ff@163.com","publicName":"测试公众号","description":"","publicId":3,"fullName":"flyf","roleId":1},
				{"enabled":"启用","status":0,"roleName":"一般权限","version":1,"id":5,"username":"gf","area":"省分","email":"gf","publicName":"测试公众号","description":"gf","publicId":3,"fullName":"gf","roleId":4}
			];
		var str = $("#grid-table").find("input:checked").parents("tr").find("td[aria-describedby='grid-table_id']").text();
		examin_arr = examin_string.filter(function(item){ 
		    return item.id==str;
		});
		$("#info_name").find("input").val(examin_arr[0].username);
		$("#info_name2").find("input").val(examin_arr[0].fullName);
		// if($("#info_role").find('option[value="'+examin_arr[0].roleName+'"]')){
		// 	console.log(1);
		// }else{
		// 	console.log(2);
		// }
		$("#info_state select").each(function(i){
			var index = examin_arr[0].status;
			$(this).find("option").eq("'+index+'").attr("selected",true).siblings("option").attr("selected",false);
		});
//		$("#info_state").find('option[value="'+examin_arr[0].enabled+'"]').attr("selected",true).siblings("option").attr("selected",false);
		$("#info_email").find("input").val(examin_arr[0].email);
		$("#info_role").find('option[value="'+examin_arr[0].roleName+'"]').attr("selected",true).siblings("option").attr("selected",false);
		$("#info_region").find('option[value="'+examin_arr[0].area+'"]').attr("selected",true).siblings("option").attr("selected",false);
		$("#info_public").find('option[value="'+examin_arr[0].publicName+'"]').attr("selected",true).siblings("option").attr("selected",false);
		$("#info_remarks").find("input").val(examin_arr[0].description);
}
	$("#grid-pager_left").on("click","td",function(){
	      var text=$(this).attr("data-original-title");  
		  var title=$(this).attr("data-title"); 
	      if(text=="增加权限"){	 
	         info_alert(text,title);
	         info_reset();
             $("#sure_cancel").hide();
             $("#single_close").hide();
             $("#reset_close").show();
             $(".info_password").css("display","inline-block");
           
	      	}else if(text=="修改权限"){
	      		var checked_l=$("#grid-table").find("input:checked").length;

	      		if(checked_l==1){
	      			info_alert(text,title); 
	      			$("#sure_cancel").show();
            		$("#single_close").hide();
             		$("#reset_close").hide();  
                    $(".info_password").css("display","none");
					info_examine();
	      		}else if(checked_l>1){
                    warn_(checked_l);
	      		}
	      		else if(checked_l==0){
                    warn_(checked_l);
	      		}
             
	      	}else if(text=="查看权限"){
	      		var che_l=$("#grid-table").find("input:checked").length;
	      		if(che_l==1){
	      			info_alert(text,title);

                    $("#sure_cancel").hide();
                    $("#single_close").show();
                    $("#reset_close").hide(); 
                    $(".info_password").css("display","none");
					info_examine();

	      		}else if(che_l>1){
	      			warn_(che_l);
	      		}else if(che_l==0){
	      			warn_(che_l);
	      		}
	      	}else if(text=="删除选项"){
	      		var che_l=$("#grid-table").find("input:checked").length;
	      		if(che_l>=1){
	      			$("#write_del").css("display","inline-block");
					var html="<div class='black_div'></div>";
	   					 $("body").append(html);  
	      		}else if(che_l==0){
	      			warn_(che_l);
	      		}
	      	}		     
    })

$(".widget-toolbar").on("click","span",function(){
	write_Look();
})
/*弹出框*/
$(".save_bottom").on("click",".cancel_btn",function(){
	write_Look();
})
$("#sData").on("click",function(){
	var inline_item=$("#tr_id").find("input").val(),
	    date_txt=$("#tr_sdate").find("input").val(),
	    name_txt=$("#tr_name").find("input").val(),
	    status_txt=$("#tr_stock").find("input").prop("checked"),
	    team_txt=$("#tr_ship").find("input").val(),
	    bei_txt=$("#tr_note").find("textarea").val();
        if(status_txt==true){
        	status_true=$("#tr_stock").find("input").val();
        }else{
        	status_false=$("#tr_stock").find("input").attr("offval");
        }
        if(inline_item!=""&&date_txt!=""&&name_txt!=""&&team_txt!=""){
        	$.ajax({
        		url:"roles.html",
        		data:{
        			data_item:inline_item,
        			data_date:date_txt,
                    data_name:name_txt,
                    data_status:status_true || status_false,
                    data_team:team_txt,
                    data_bei:bei_txt
        		},
        		type:"get",
        		success:function(datas){
                     console.log(datas);
        		}
        		
        	})
        }
})
function empty(){
	$("#info_name").find("input").val("");
	$("#info_static").find("input:eq(0)").prop("checked",true);
	$("#bei_zhu").find("textarea").val("");
}
$("#reset_close").on("click","",function(){
   empty();
})
$("#widet_body").on("focus","input",function(){
	var value = $(this).val();

	 $(this).siblings(".admini_block").css("display","none");

})
$("#widet_body").on("click","select",function(){

	 $(this).siblings(".admini_inline").css("display","none");

})
$("#btn_edit").on("click",function(){

	$("#widet_body input").each(function(){
	    var value = $(this).val();
	    if(value==""){
	    	$(this).siblings(".admini_block").css("display","inline-block");
	    }else{
	    	console.log(value);
	    	$(this).siblings(".admini_block").css("display","none");
	    }

	});
	$("#widet_body select").each(function(){
	    var value = $(this).find("option:selected").text();
		if(value=="请选择"){
	    	$(this).siblings(".admini_inline").css("display","inline-block");
	    }else{
	    	console.log(value);
	    	$(this).siblings(".admini_inline").css("display","none");
	    }
	});
	
})
$("#reset_btn").on("click",function(){
	$("#widet_body input").each(function(){
	    var value = $(this).val("");

	});
	$(".admini_inline").css("display","none");
    $(".admini_block").css("display","none");
	$("#widet_body select").each(function(i){
		$(this).find("option").eq(0).attr("selected",true).siblings("option").attr("selected",false);
	});
})

})(jQuery)